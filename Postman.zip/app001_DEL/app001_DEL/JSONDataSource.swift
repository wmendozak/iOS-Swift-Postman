//
//  JSONDataSource.swift
//  app001_DEL
//
//  Created by wmendozak on 2023-02-09.
//

import UIKit

class JSONDataSource: NSObject, ObservableObject {
    
    @Published var results = [Results]()
    
    override init() {
        super.init()
        results = [Results]()
        /*let urlString = "https://tools.cdc.gov/api/v2/resources/media"
        StorageFunctions.getJSON(urlString: urlString) { [unowned self] (news:NewsFeed?) in
            if let news = news {
                self.results = news.results!
            }
        }*/
    }
    
    func displayUrlJSON(urlString: String) {
        StorageFunctions.getJSON(urlString: urlString) { [unowned self] (news:NewsFeed?) in
            if let news = news {
                self.results = news.results!
            }
        }
    }
}
