//
//  ContentView.swift
//  app001_DEL
//
//  Created by wmendozak on 2023-02-07.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var newsFeedSource:JSONDataSource
    @State private var urlString: String = ""
    
    var body: some View {
        HStack{
            Button("SEARCH") {
                self.newsFeedSource.displayUrlJSON(urlString: self.urlString)
            }
            TextField("URL", text: $urlString)
        }.padding()
        VStack{
            NavigationView {
                VStack {
                    List(){
                        ForEach (newsFeedSource.results) { result in
                            VStack(alignment: .leading){
                                Text("id: \(result.id!)").font(.headline)
                                Text("name: \(result.name!)").font(.headline)
                                Text("url: \(result.url!)").font(.headline)
                                Text("contentURL: \(result.contentUrl!) ").font(.headline)
                            }
                            //Spacer()
                        }
                    }
                }
            }.navigationViewStyle(StackNavigationViewStyle())
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environmentObject(JSONDataSource())
    }
}
