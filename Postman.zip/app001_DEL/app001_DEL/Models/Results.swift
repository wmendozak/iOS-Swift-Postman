//
//  results.swift
//  app001_DEL
//
//  Created by wmendozak on 2023-02-08.
//

import Foundation

struct Results:Codable, Identifiable {
    var id:Int?
    var url:String?
    var name:String?
    var contentUrl:String?
}
