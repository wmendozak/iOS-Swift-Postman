//
//  meta.swift
//  app001_DEL
//
//  Created by wmendozak on 2023-02-08.
//

import Foundation

struct Meta: Codable {
    var status:Int?
    //var message:[String]?
}
