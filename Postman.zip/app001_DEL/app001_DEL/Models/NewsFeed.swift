//
//  NewsFeed.swift
//  app001_DEL
//
//  Created by wmendozak on 2023-02-08.
//

import Foundation

struct NewsFeed: Codable {
    var meta : Meta?
    var results : [Results]?
    
    /*
     enum CodingKeys : String, CodingKey {
        case meta
        case results
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        meta = try values.decode(Meta.self, forKey: .meta)
        results = try values.decode([Results].self, forKey: .results)
    }
 */
}
