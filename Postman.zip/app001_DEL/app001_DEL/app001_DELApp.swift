//
//  app001_DELApp.swift
//  app001_DEL
//
//  Created by wmendozak on 2023-02-07.
//

import SwiftUI

@main
struct app001_DELApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(JSONDataSource())
        }
    }
}
